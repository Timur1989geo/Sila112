export default function Product() {
  return (
    <div>
      <h1>Пихтовое мыло</h1>
      <p>Описание пихтовое мыло будет добавлено позже.</p>
    </div>
  );
}
