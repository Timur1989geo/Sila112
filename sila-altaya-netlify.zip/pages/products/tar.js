export default function Product() {
  return (
    <div>
      <h1>Дегтярное мыло</h1>
      <p>Описание дегтярное мыло будет добавлено позже.</p>
    </div>
  );
}
