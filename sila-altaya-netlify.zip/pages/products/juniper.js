export default function Product() {
  return (
    <div>
      <h1>Можжевеловое мыло</h1>
      <p>Описание можжевеловое мыло будет добавлено позже.</p>
    </div>
  );
}
