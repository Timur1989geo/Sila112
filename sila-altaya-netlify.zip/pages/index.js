export default function Home() {
  return (
    <div>
      <h1>Сила Алтая</h1>
      <p>Добро пожаловать в магазин натурального мыла ручной работы.</p>
    </div>
  );
}
